var PRIMARY_CONFIG_KEY = "primary_configuration";
var DICE_NOTATION_REGEX = /^(\d+)?d(\d+)([+-]\d+)?$/
var ROLL_DELAY = 55;
var ROLL_INCREMENT = 8;
var ROLLS_PER_ANIMATION = 15;
var DEFAULT_CONFIGURATION = new Configuration("white", false, true, [], false);
